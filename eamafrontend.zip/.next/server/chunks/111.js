"use strict";
exports.id = 111;
exports.ids = [111];
exports.modules = {

/***/ 1111:
/***/ ((module) => {

module.exports = JSON.parse('{"test":"تجربة","The email must be a valid email address.":"يجب أن يكون البريد الإلكتروني عنوان بريد إلكتروني صالحًا.","the email or password is incorrect":"البريد الإلكتروني أو كلمة المرور غير صحيحة","":""}');

/***/ })

};
;