exports.id = 116;
exports.ids = [116];
exports.modules = {

/***/ 8556:
/***/ ((module) => {

// Exports
module.exports = {
	"ButtonsS1": "buttons_ButtonsS1__Kn9mZ"
};


/***/ }),

/***/ 4189:
/***/ ((module) => {

// Exports
module.exports = {
	"servicesCard": "cards_servicesCard__clIBx",
	"blogCard": "cards_blogCard__k2tDe"
};


/***/ }),

/***/ 6332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonsS1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8556);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function ButtonsS1({ text , iconB , iconA , className , type , loading , disabled =false ,  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "ButtonsS1 " + (_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default().ButtonsS1),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
            className: className,
            htmlType: type,
            loading: loading,
            disabled: disabled,
            children: [
                iconB,
                text,
                iconA
            ]
        })
    });
}


/***/ })

};
;