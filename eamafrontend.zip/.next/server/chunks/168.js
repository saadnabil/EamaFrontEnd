"use strict";
exports.id = 168;
exports.ids = [168];
exports.modules = {

/***/ 773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UJ": () => (/* binding */ getBlogPage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export glogSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    blog: {}
};
const getBlogPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("blog/getBlogPage", async (payload, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/blog-page?page=${payload}`);
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const glogSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "blog",
    initialState,
    reducers: {},
    extraReducers: {
        [getBlogPage.pending]: (state)=>{
            state.loading = true;
        },
        [getBlogPage.fulfilled]: (state, action)=>{
            state.blog = action?.payload.data;
            state.loading = false;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            if (action.payload?.index?.blog) {
                state.blog = action.payload;
            }
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (glogSlice.reducer);


/***/ })

};
;