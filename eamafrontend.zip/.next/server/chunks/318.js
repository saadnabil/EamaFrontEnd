"use strict";
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 6318:
/***/ ((module) => {

module.exports = JSON.parse('{"welcome":"login 2","login":"login"}');

/***/ })

};
;