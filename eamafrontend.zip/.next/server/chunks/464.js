"use strict";
exports.id = 464;
exports.ids = [464];
exports.modules = {

/***/ 464:
/***/ ((module) => {

module.exports = JSON.parse('{"test":"test","The email must be a valid email address.":"The email must be a valid email address.","the email or password is incorrect":"the email or password is incorrect","":""}');

/***/ })

};
;