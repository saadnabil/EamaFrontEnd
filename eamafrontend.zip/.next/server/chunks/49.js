"use strict";
exports.id = 49;
exports.ids = [49];
exports.modules = {

/***/ 453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "v0": () => (/* binding */ getAboutPage)
/* harmony export */ });
/* unused harmony export aboutSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    about: {}
};
const getAboutPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("about/getAboutPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/about-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const aboutSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "about",
    initialState,
    reducers: {},
    extraReducers: {
        [getAboutPage.pending]: (state)=>{
            state.loading = true;
        },
        [getAboutPage.fulfilled]: (state, action)=>{
            state.about = action?.payload?.data;
            state.loading = false;
        },
        [getAboutPage.rejected]: (state, action)=>{
            state.apiErrors = "";
            state.loading = false;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            state.about = action.payload.about.about;
            if (action?.payload?.about?.about) {
                console.log("----", action.payload.about.about);
            }
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (aboutSlice.reducer);


/***/ }),

/***/ 4808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xo": () => (/* binding */ setFirstLoad),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports authSlice, setCheckUser */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    checkUser: false,
    firstLoad: false,
    data: [],
    users: [],
    loading: false
};
// export const getCity = createAsyncThunk('counter/getCity',
//     async () => {
//         try {
//             const data = await axios('https://api.pillpipe.com/api/getCity')
//             return data.data
//             // handle result here
//         } catch (error) {
//             // handle error here
//         }
//     })
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        setFirstLoad: (state, action)=>{
            state.firstLoad = action.payload;
        },
        setCheckUser: (state, action)=>{
            state.checkUser = action.payload;
        }
    }
});
// Action creators are generated for each case reducer function
const { setCheckUser , setFirstLoad  } = authSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);


/***/ }),

/***/ 6773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fz": () => (/* binding */ careerFormThunk),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "kt": () => (/* binding */ getCareersPage)
/* harmony export */ });
/* unused harmony export getCareersSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    careers: {}
};
const getCareersPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("careers/getCareersPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/career-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const careerFormThunk = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("careers/careerFormThunk", async (payload, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/career", payload);
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const getCareersSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "careers",
    initialState,
    reducers: {},
    extraReducers: {
        [getCareersPage.pending]: (state)=>{
            state.loading = true;
        },
        [getCareersPage.fulfilled]: (state, action)=>{
            state.careers = action?.payload.data;
            state.loading = false;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            if (action.payload?.index?.careers) {
                state.careers = action.payload;
            }
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getCareersSlice.reducer);


/***/ }),

/***/ 8286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J4": () => (/* binding */ getContactPage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "qy": () => (/* binding */ contactFormThunk)
/* harmony export */ });
/* unused harmony export contactSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    contact: {}
};
const getContactPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("contact/getContactPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/contact-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const contactFormThunk = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("contact/contactFormThunk", async (payload, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/contact", payload);
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const contactSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "contact",
    initialState,
    reducers: {},
    extraReducers: {
        [getContactPage.pending]: (state)=>{
            state.loading = true;
        },
        [getContactPage.fulfilled]: (state, action)=>{
            state.contact = action?.payload.data;
            state.loading = false;
        },
        [getContactPage.rejected]: (state, action)=>{},
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            state.contact = action.payload.contact.contact;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contactSlice.reducer);


/***/ }),

/***/ 483:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fl": () => (/* binding */ getCustomersPage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export aboutSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    customers: {}
};
const getCustomersPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("customers/getCustomersPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/client-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const aboutSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "customers",
    initialState,
    reducers: {},
    extraReducers: {
        [getCustomersPage.pending]: (state)=>{
            state.loading = true;
        },
        [getCustomersPage.fulfilled]: (state, action)=>{
            state.customers = action?.payload.data;
            state.loading = false;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            if (action.payload?.index?.customers) {
                state.customers = action.payload;
            }
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (aboutSlice.reducer);


/***/ }),

/***/ 5307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ME": () => (/* binding */ getIndexPage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export indexSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    index: {}
};
const getIndexPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("index/getIndexPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/home-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const indexSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "index",
    initialState,
    reducers: {},
    extraReducers: {
        [getIndexPage.pending]: (state)=>{
            state.loading = true;
        },
        [getIndexPage.fulfilled]: (state, action)=>{
            state.index = action?.payload.data;
            state.loading = false;
        },
        [getIndexPage.rejected]: (state, action)=>{
        // state.index = action;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            state.index = action.payload.index.index;
            console.log(action.payload.index.index);
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (indexSlice.reducer);


/***/ }),

/***/ 9856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JZ": () => (/* binding */ quotationFormThunk),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "_c": () => (/* binding */ getQuotationPage)
/* harmony export */ });
/* unused harmony export getQuotationSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__);



const initialState = {
    loading: false,
    apiErrors: [],
    customers: {}
};
const getQuotationPage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("quotation/getQuotationPage", async (_, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/quotation-page");
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const quotationFormThunk = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("quotation/quotationFormThunk", async (payload, { rejectWithValue  })=>{
    try {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/quotation", payload);
        return data.data;
    } catch (error) {
        return rejectWithValue(error.response);
    }
});
const getQuotationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "quotation",
    initialState,
    reducers: {},
    extraReducers: {
        [getQuotationPage.pending]: (state)=>{
            state.loading = true;
        },
        [getQuotationPage.fulfilled]: (state, action)=>{
            state.quotation = action?.payload.data;
            state.loading = false;
        },
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_2__.HYDRATE]: (state, action)=>{
            if (action.payload?.index?.quotation) {
                state.quotation = action.payload;
            }
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getQuotationSlice.reducer);


/***/ }),

/***/ 5049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ wrapper)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _slices_about_aboutSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(453);
/* harmony import */ var _slices_auth_authSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4808);
/* harmony import */ var _slices_blog_blogSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(773);
/* harmony import */ var _slices_careers_careersSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6773);
/* harmony import */ var _slices_contact_contactSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8286);
/* harmony import */ var _slices_customers_customersSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(483);
/* harmony import */ var _slices_index_indexSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5307);
/* harmony import */ var _slices_quotation_quotationSlice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9856);



//







const makeStore = ()=>(0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
        reducer: {
            auth: _slices_auth_authSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
            index: _slices_index_indexSlice__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP,
            about: _slices_about_aboutSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
            customers: _slices_customers_customersSlice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP,
            quotation: _slices_quotation_quotationSlice__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP,
            careers: _slices_careers_careersSlice__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
            blog: _slices_blog_blogSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
            contact: _slices_contact_contactSlice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP
        },
        devTools: true
    });
const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(makeStore);


/***/ })

};
;