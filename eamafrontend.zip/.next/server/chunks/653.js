"use strict";
exports.id = 653;
exports.ids = [653];
exports.modules = {

/***/ 1097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "S": () => (/* binding */ Contact_section)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "antd/lib/input/TextArea"
var TextArea_ = __webpack_require__(5842);
var TextArea_default = /*#__PURE__*/__webpack_require__.n(TextArea_);
// EXTERNAL MODULE: ./components/tools/buttons/buttonsS1.js
var buttonsS1 = __webpack_require__(6332);
;// CONCATENATED MODULE: ./components/tools/sections/forms/contact_form.js




const Contact_form = ()=>{
    const onFinish = (values)=>{
        console.log("Success:", values);
    };
    const onFinishFailed = (errorInfo)=>{
        console.log("Failed:", errorInfo);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Form, {
            name: "basic",
            wrapperCol: {
                span: 24
            },
            onFinish: onFinish,
            onFinishFailed: onFinishFailed,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    name: "username",
                    rules: [
                        {
                            required: true,
                            message: "Please input your username!"
                        }, 
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                        placeholder: "Name"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    name: "email",
                    rules: [
                        {
                            required: true,
                            message: "Please input your username!"
                        }, 
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                        type: "email",
                        placeholder: "Email"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    name: "subject",
                    rules: [
                        {
                            required: true,
                            message: "Please input your username!"
                        }, 
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                        placeholder: "Subjct"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    name: "username",
                    rules: [
                        {
                            required: true,
                            message: "Please input your username!"
                        }, 
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx((TextArea_default()), {
                        placeholder: "Massage"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(buttonsS1/* default */.Z, {
                        text: "send",
                        className: "contactBtn"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/tools/sections/contact_section.js



const { Panel  } = external_antd_.Collapse;
const Contact_section = ({ data  })=>{
    const onChange = (key)=>{
        console.log(key);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "contactSection container_ overlay",
        style: {
            backgroundImage: `url(${data?.image})`
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
            gutter: 80,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                    xs: 24,
                    lg: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "contactContent",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "subTitle",
                                children: data?.subtitle
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "mainHeading",
                                children: data?.title
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Collapse, {
                                defaultActiveKey: [
                                    1
                                ],
                                onChange: onChange,
                                accordion: true,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Panel, {
                                        header: "This is panel header 1",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                data?.description,
                                                " "
                                            ]
                                        })
                                    }, 1),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Panel, {
                                        header: "This is panel header 2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "it can be found as a welcome guest in many households across the world."
                                        })
                                    }, 2),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Panel, {
                                        header: "This is panel header 3",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "it can be found as a welcome guest in many households across the world."
                                        })
                                    }, 3)
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                    xs: 24,
                    lg: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "contactForm",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    "reach out via the ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " form below"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Contact_form, {})
                        ]
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 4980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ Customers_section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _swipers_customers_swiper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6835);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_swipers_customers_swiper__WEBPACK_IMPORTED_MODULE_2__]);
_swipers_customers_swiper__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Customers_section = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "customersSection container_",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_swipers_customers_swiper__WEBPACK_IMPORTED_MODULE_2__/* .Customers_swiper */ .r, {
            data: data
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "r": () => (/* binding */ Exepert_section)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(241);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-scroll-trigger"
var external_react_scroll_trigger_ = __webpack_require__(908);
var external_react_scroll_trigger_default = /*#__PURE__*/__webpack_require__.n(external_react_scroll_trigger_);
;// CONCATENATED MODULE: ./components/tools/progress/lineProgress.js




const LineProgress = ({ max , time , title  })=>{
    const { 0: percent , 1: setPersent  } = (0,external_react_.useState)(0);
    const { 0: start , 1: setStart  } = (0,external_react_.useState)(false);
    const onEnter = ()=>{
        setStart(true);
    };
    const onExit = ()=>{
        setPersent(0);
        setStart(false);
    };
    start && setTimeout(()=>{
        if (percent <= max - 1) {
            setPersent(percent + 1);
        }
    }, [
        time
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "progres",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_scroll_trigger_default()), {
            onEnter: onEnter,
            onExit: onExit,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flexBetween",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                percent,
                                "%"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Progress, {
                    percent: percent,
                    strokeColor: "#f90606",
                    strokeWidth: 4,
                    showInfo: false
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/tools/sections/exepert_section.js




const Exepert_section = ({ data  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "expertSection",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                    xs: 24,
                    lg: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "left overlay",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "imageTransition",
                                style: {
                                    backgroundImage: `url(${data?.image_one})`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "cardContent",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: data?.title
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                    xs: 24,
                    lg: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "right overlay",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "imageTransition",
                                style: {
                                    backgroundImage: `url(${data?.image_two})`
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "cardContent",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: data?.descrition
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "progress",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(LineProgress, {
                                                max: data?.number_one,
                                                time: 15,
                                                title: data?.title_one
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(LineProgress, {
                                                max: data?.number_two,
                                                time: 15,
                                                title: data?.title_two
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(LineProgress, {
                                                max: data?.number_three,
                                                time: 15,
                                                title: data?.title_three
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 7073:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ OurTeam_section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const OurTeam_section = ({ data , titleData  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ourTeamSection container_ overlay",
        style: {
            backgroundImage: `url(${titleData?.image})`
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "heading",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "subTitle",
                        children: titleData?.subtitle
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                        className: "mainHeading",
                        children: [
                            titleData?.title,
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Row, {
                gutter: 40,
                children: data?.map((teamMember, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Col, {
                        xs: 24,
                        md: 8,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "teamMember",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "image",
                                    style: {
                                        backgroundImage: `url(${teamMember?.image})`
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "info",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            children: teamMember.name
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: teamMember.description
                                        })
                                    ]
                                })
                            ]
                        })
                    }, i))
            })
        ]
    });
};


/***/ }),

/***/ 6835:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ Customers_swiper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3877);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(241);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_2__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const Customers_swiper = ({ data  })=>{
    const breakpoints = {
        200: {
            slidesPerView: 1,
            spaceBetween: 23
        },
        400: {
            slidesPerView: 2,
            spaceBetween: 23
        },
        700: {
            slidesPerView: 3,
            spaceBetween: 40
        },
        1024: {
            slidesPerView: 5,
            spaceBetween: 40
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "customersSwiper",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper, {
            slidesPerGroup: 1,
            loop: true,
            loopFillGroupWithBlank: true,
            navigation: true,
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_2__.Navigation
            ],
            className: "mySwiper",
            breakpoints: breakpoints,
            speed: 1000,
            children: data?.map((client, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "card",
                        style: {
                            backgroundImage: `url(${client?.image})`
                        }
                    })
                }))
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2983:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ Testimonials_swiper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3877);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(241);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_2__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const Testimonials_swiper = ({ data  })=>{
    const breakpoints = {
        200: {
            slidesPerView: 1,
            spaceBetween: 23
        },
        400: {
            slidesPerView: 1,
            spaceBetween: 23
        },
        700: {
            slidesPerView: 1,
            spaceBetween: 40
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 40
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "testimonialsSwiper",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper, {
            slidesPerGroup: 1,
            loop: true,
            loopFillGroupWithBlank: true,
            navigation: true,
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_2__.Navigation
            ],
            className: "mySwiper",
            speed: 1000,
            breakpoints: breakpoints,
            children: data?.map((slider, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "customer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "imgContainer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: slider.image,
                                    width: 200,
                                    height: 200,
                                    alt: "imgContainer"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: slider.description
                            })
                        ]
                    })
                }, i))
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2556:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ Testimonials_section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _swipers_testimonials_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2983);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_swipers_testimonials_swiper__WEBPACK_IMPORTED_MODULE_1__]);
_swipers_testimonials_swiper__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Testimonials_section = ({ data , titleData  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "testimonialsSection",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "contentHeading",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "icon",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaQuoteLeft, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "mainHeading",
                        children: titleData?.title
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_swipers_testimonials_swiper__WEBPACK_IMPORTED_MODULE_1__/* .Testimonials_swiper */ .t, {
                data: data
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;