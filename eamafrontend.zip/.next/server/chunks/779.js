"use strict";
exports.id = 779;
exports.ids = [779];
exports.modules = {

/***/ 7779:
/***/ ((module) => {

module.exports = JSON.parse('{"validate":"validate","The email must be a valid email address.":"The email must be a valid email address."}');

/***/ })

};
;