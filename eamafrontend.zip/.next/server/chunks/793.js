"use strict";
exports.id = 793;
exports.ids = [793];
exports.modules = {

/***/ 793:
/***/ ((module) => {

module.exports = JSON.parse('{"validate":"تحقق","---msg":"","The email must be a valid email address.":"يجب أن يكون البريد الإلكتروني عنوان بريد إلكتروني صالحًا."}');

/***/ })

};
;