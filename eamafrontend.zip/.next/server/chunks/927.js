"use strict";
exports.id = 927;
exports.ids = [927];
exports.modules = {

/***/ 4927:
/***/ ((module) => {

module.exports = JSON.parse('{"welcome":"تسجيل  2","login":"دخول"}');

/***/ })

};
;