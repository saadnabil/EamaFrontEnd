(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7655:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ar/common": [
		1111,
		111
	],
	"./ar/common.json": [
		1111,
		111
	],
	"./ar/login": [
		4927,
		927
	],
	"./ar/login.json": [
		4927,
		927
	],
	"./ar/validate": [
		793,
		793
	],
	"./ar/validate.json": [
		793,
		793
	],
	"./en/common": [
		464,
		464
	],
	"./en/common.json": [
		464,
		464
	],
	"./en/login": [
		6318,
		318
	],
	"./en/login.json": [
		6318,
		318
	],
	"./en/validate": [
		7779,
		779
	],
	"./en/validate.json": [
		7779,
		779
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(() => {
		return __webpack_require__.t(id, 3 | 16);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 7655;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 2053:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__QO2rN"
};


/***/ }),

/***/ 2168:
/***/ ((module) => {

// Exports
module.exports = {
	"headerPages": "header_headerPages__fPBg2"
};


/***/ }),

/***/ 9827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./i18n.json
const i18n_namespaceObject = JSON.parse('{"locales":["ar","en"],"defaultLocale":"en","localeDetection":false,"pages":{"*":["common","validate"],"/":["login"],"/about":["about"]}}');
;// CONCATENATED MODULE: external "next-translate/appWithI18n"
const appWithI18n_namespaceObject = require("next-translate/appWithI18n");
var appWithI18n_default = /*#__PURE__*/__webpack_require__.n(appWithI18n_namespaceObject);
// EXTERNAL MODULE: ./node_modules/antd/dist/antd.css
var antd = __webpack_require__(4722);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./layout/header/style/header.module.scss
var header_module = __webpack_require__(2168);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(241);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5657);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-icons/hi"
const hi_namespaceObject = require("react-icons/hi");
;// CONCATENATED MODULE: ./layout/header/sections/menu.js






const Menue = ()=>{
    const { 0: visible , 1: setVisible  } = (0,external_react_.useState)(false);
    const router = (0,router_namespaceObject.useRouter)();
    const showDrawer = ()=>{
        setVisible(true);
    };
    const onClose = ()=>{
        setVisible(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "menuPage",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "menuPageBtn",
                    onClick: showDrawer,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(hi_namespaceObject.HiMenuAlt1, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Drawer, {
                    placement: "right",
                    closable: false,
                    onClose: onClose,
                    visible: visible,
                    className: "menuPageDrawer",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "menuPageHeader",
                            onClick: onClose,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(hi_namespaceObject.HiMenuAlt1, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "content",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "Home"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/about" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/about",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "About"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/customers" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/customers",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "customers"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/request-qutation" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/request-qutation",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "request qutation"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/careers" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/careers",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "careers"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/blog" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/blog",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "blog"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/bilboard" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/bilboard",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "Billboards' locations"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: router.pathname === "/contact-us" ? "active" : "",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact-us",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: "CONTACT"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }, "right")
            ]
        })
    });
};
/* harmony default export */ const menu = (Menue);

;// CONCATENATED MODULE: ./layout/header/header.js







function HeaderApp() {
    const router = (0,router_namespaceObject.useRouter)();
    const { 0: scroll , 1: setScroll  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", ()=>{
            setScroll(window.scrollY > 10);
        });
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: (header_module_default()).headerPages,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `container_` + (scroll ? " headerS2" : ""),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "header_center flex__",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "header_sec1 flex__",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "logo",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: "/images/logo.png",
                                            width: 158,
                                            height: 54
                                        })
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(menu, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "flex__ header_sec2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "Home"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/about" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/about",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "About"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/customers" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/customers",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "customers"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/request-qutation" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/request-qutation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "request qutation"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/careers" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/careers",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "careers"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/blog" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/blog",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "blog"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/bilboard" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/bilboard",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "Billboards' locations"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: router.pathname === "/contact-us" ? "active" : "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/contact-us",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: "CONTACT"
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const header = (HeaderApp);

// EXTERNAL MODULE: ./layout/footer/footer.module.scss
var footer_module = __webpack_require__(2053);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/gr"
var gr_ = __webpack_require__(8547);
;// CONCATENATED MODULE: external "react-icons/fi"
const fi_namespaceObject = require("react-icons/fi");
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./layout/footer/footer.js









function Footer() {
    const onFinish = (values)=>{
        console.log("Success:", values);
    };
    const onFinishFailed = (errorInfo)=>{
        console.log("Failed:", errorInfo);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
            className: (footer_module_default()).footer,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "topFooter",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                lg: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "left container_",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "mainHeading",
                                        children: "WANT TO WORK WITH US?"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                lg: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "right container_",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "CONTACT US"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "(+68) 120034509"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "info@yourdomain.com"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                "005 Stokes Isle Apt. 896, ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                "enaville 10010, USA"
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "secondFooter container_",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                        gutter: 20,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                md: 24,
                                lg: 7,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "logo",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: "/images/logo.png",
                                                    width: 158,
                                                    height: 54
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                "\xa9 Copyrights 2021 Outmedia ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                "All rights reserved."
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                sm: 12,
                                lg: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footerUl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "footerHeading",
                                            children: "LINKS"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    children: "Home"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/about",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "About"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/customers",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Customers"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/request-qutation",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Request-qutation"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/careers",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Careers"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                sm: 12,
                                lg: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footerUl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "footerHeading",
                                            children: "LINKS"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/blog",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Blog"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/contact-us",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Contact Us"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/bilboard",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: "Bilboard"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                                xs: 24,
                                md: 24,
                                lg: 5,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "socail",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "footerHeading",
                                            children: "SUBSCRIBE"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form, {
                                            name: "basic",
                                            onFinish: onFinish,
                                            onFinishFailed: onFinishFailed,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                                name: "email",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input your username!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "subscribe",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon1",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsEnvelope, {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                                            placeholder: "Email"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon2",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(fi_namespaceObject.FiSend, {})
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex_",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(gr_.GrFacebookOption, {})
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineTwitter, {})
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillYoutube, {})
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillInstagram, {})
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "bottomFooter",
                    children: "\xa9 2022, EMMA. All rights reserved"
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: external "next-translate/useTranslation"
const useTranslation_namespaceObject = require("next-translate/useTranslation");
var useTranslation_default = /*#__PURE__*/__webpack_require__.n(useTranslation_namespaceObject);
;// CONCATENATED MODULE: ./layout/layout.js






function LayoutApp({ children  }) {
    const { t , lang  } = useTranslation_default()();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.ConfigProvider, {
            direction: lang === "ar" ? "rtl" : "ltr",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "app_",
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
            ]
        })
    });
}
/* harmony default export */ const layout = (LayoutApp);

// EXTERNAL MODULE: ./store/store.js
var store = __webpack_require__(5049);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./store/slices/auth/authSlice.js
var authSlice = __webpack_require__(4808);
;// CONCATENATED MODULE: ./layout/setApp.js





function SetApp({ children  }) {
    const { t , lang  } = useTranslation_default()();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { firstLoad  } = (0,external_react_redux_.useSelector)(({ auth  })=>auth);
    (0,external_react_.useEffect)(()=>{
        (external_axios_default()).defaults.headers.common.lang = lang;
        (external_axios_default()).defaults.baseURL = "https://admin.eama.site/api/v1/";
    }, []);
    (0,external_react_.useEffect)(()=>{
        dispatch((0,authSlice/* setFirstLoad */.Xo)(true));
    }, []);
    return firstLoad && children;
}
/* harmony default export */ const setApp = (SetApp);

;// CONCATENATED MODULE: external "react-cookie"
const external_react_cookie_namespaceObject = require("react-cookie");
;// CONCATENATED MODULE: ./pages/_app.js













function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_cookie_namespaceObject.CookiesProvider, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(setApp, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(layout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        })
    });
}
// const __Page_Next_Translate__ = MyApp
const __Page_Next_Translate__ = store/* wrapper.withRedux */.Y.withRedux(MyApp);
/* harmony default export */ const _app = (appWithI18n_default()(__Page_Next_Translate__, {
    ...i18n_namespaceObject,
    isLoader: true,
    skipInitialProps: false,
    loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
}));


/***/ }),

/***/ 4722:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [241,754,657,168,49], () => (__webpack_exec__(9827)));
module.exports = __webpack_exports__;

})();