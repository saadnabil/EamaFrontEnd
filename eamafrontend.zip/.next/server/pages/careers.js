(() => {
var exports = {};
exports.id = 698;
exports.ids = [698];
exports.modules = {

/***/ 5714:
/***/ ((module) => {

// Exports
module.exports = {
	"careers": "careers_careers__rg8nm"
};


/***/ }),

/***/ 8556:
/***/ ((module) => {

// Exports
module.exports = {
	"ButtonsS1": "buttons_ButtonsS1__Kn9mZ"
};


/***/ }),

/***/ 6332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonsS1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8556);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function ButtonsS1({ text , iconB , iconA , className , type , loading , disabled =false ,  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "ButtonsS1 " + (_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default().ButtonsS1),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
            className: className,
            htmlType: type,
            loading: loading,
            disabled: disabled,
            children: [
                iconB,
                text,
                iconA
            ]
        })
    });
}


/***/ }),

/***/ 933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ careers),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/careers/style/careers.module.scss
var careers_module = __webpack_require__(5714);
var careers_module_default = /*#__PURE__*/__webpack_require__.n(careers_module);
// EXTERNAL MODULE: ./components/tools/sections/pageHeading_section.js
var pageHeading_section = __webpack_require__(5895);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(241);
// EXTERNAL MODULE: external "antd/lib/input/TextArea"
var TextArea_ = __webpack_require__(5842);
var TextArea_default = /*#__PURE__*/__webpack_require__.n(TextArea_);
;// CONCATENATED MODULE: external "antd/lib/upload/Dragger"
const Dragger_namespaceObject = require("antd/lib/upload/Dragger");
var Dragger_default = /*#__PURE__*/__webpack_require__.n(Dragger_namespaceObject);
// EXTERNAL MODULE: ./components/tools/buttons/buttonsS1.js
var buttonsS1 = __webpack_require__(6332);
;// CONCATENATED MODULE: external "@ant-design/icons"
const icons_namespaceObject = require("@ant-design/icons");
// EXTERNAL MODULE: ./store/slices/careers/careersSlice.js
var careersSlice = __webpack_require__(6773);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/careers/forms/careers_form.js









const Careers_form = ()=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { 0: cvId , 1: setCvId  } = (0,external_react_.useState)(null);
    const onFinish = (values)=>{
        dispatch((0,careersSlice/* careerFormThunk */.Fz)({
            ...values,
            id: cvId
        })).unwrap().then((res)=>{
            external_antd_.message.success("This is a success message");
        }).catch((res)=>{
            external_antd_.message.error("This is an error message");
        });
    };
    const onFinishFailed = (errorInfo)=>{
        console.log("Failed:", errorInfo);
    };
    const props = {
        name: "cv",
        action: `https://admin.eama.site/api/v1/upload-cv`,
        headers: {
            authorization: "authorization-text"
        },
        onChange (info) {
            if (info.file.status !== "uploading") {}
            if (info.file.status === "done") {
                setCvId(info.file.response.id);
                external_antd_.message.info(`${info.file.name} uploaded.`);
            } else if (info.file.status === "error") {
                external_antd_.message.error(`${info.file.name} file upload failed.`);
            }
        }
    };
    console.log(cvId);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "form",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Form, {
            name: "basic",
            wrapperCol: {
                span: 16
            },
            onFinish: onFinish,
            onFinishFailed: onFinishFailed,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                    gutter: 20,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "name",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your Name!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "Your Name"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "email",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your email!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "Your Email"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "phone",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your phone!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "phone"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "job_type",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please select your career type!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Select, {
                                    placeholder: "Your Career Type",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Option, {
                                            value: "Internship",
                                            children: "Internship"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Option, {
                                            value: "Fresh graduate",
                                            children: "Fresh graduate"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Option, {
                                            value: "Experienced",
                                            children: "Experienced"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Option, {
                                            value: "Professional",
                                            children: "Professional"
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "cv",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please upload cv!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "cv",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dragger_default()), {
                                        ...props,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "ant-upload-drag-icon",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_namespaceObject.InboxOutlined, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "ant-upload-text",
                                                children: "Click or drag file to this area to upload"
                                            })
                                        ]
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "message",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextArea_default()), {
                                    placeholder: "Your Massage"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(buttonsS1/* default */.Z, {
                    text: "send massage",
                    type: "submit"
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/careers/careers.js









const CareersComponent = ()=>{
    const { careers  } = (0,external_react_redux_.useSelector)(({ careers  })=>careers);
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        dispatch((0,careersSlice/* getCareersPage */.kt)());
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (careers_module_default()).careers,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(pageHeading_section/* PageHeading_section */.$, {
                data: careers.cover_section
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "careersContent container_",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "imgContainer overlay",
                                style: {
                                    backgroundImage: `url(${careers.quotation_section?.image})`
                                }
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "content",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "subTitle",
                                        children: careers.quotation_section?.subtitle
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: careers.quotation_section?.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: careers.quotation_section?.description
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Careers_form, {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./store/store.js
var store = __webpack_require__(5049);
;// CONCATENATED MODULE: ./pages/careers.js





const getServerSideProps = store/* wrapper.getServerSideProps */.Y.getServerSideProps((store)=>async (context)=>{
        await store.dispatch((0,careersSlice/* getCareersPage */.kt)());
    });
const CareersPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "emma website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "My new title"
                    }, "description"),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "My, new, title"
                    }, "keywords")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CareersComponent, {})
        ]
    });
};
/* harmony default export */ const careers = (CareersPage);


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 5842:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input/TextArea");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [241,895,168,49], () => (__webpack_exec__(933)));
module.exports = __webpack_exports__;

})();