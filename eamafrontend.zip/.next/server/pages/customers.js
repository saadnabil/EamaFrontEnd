(() => {
var exports = {};
exports.id = 525;
exports.ids = [525];
exports.modules = {

/***/ 3230:
/***/ ((module) => {

// Exports
module.exports = {
	"customers": "customers_customers__vESXI"
};


/***/ }),

/***/ 1522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ customers),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./store/slices/customers/customersSlice.js
var customersSlice = __webpack_require__(483);
// EXTERNAL MODULE: ./components/tools/sections/pageHeading_section.js
var pageHeading_section = __webpack_require__(5895);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(241);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/customers/sections/customers_section.js




const Customers_section = ()=>{
    const { customers  } = (0,external_react_redux_.useSelector)(({ customers  })=>customers);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "customersSection container_",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "topHeading",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "subTitle",
                        children: " test sub title"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "mainHeading",
                        children: "this is top heading"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Row, {
                children: customers.client?.map((customer)=>/*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                        xs: 24,
                        sm: 12,
                        lg: 6,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "customer overlay",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: customer.image,
                                    layout: "fill"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "content",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: customer.title
                                    })
                                })
                            ]
                        })
                    }, customer.id))
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/customers/style/customers.module.scss
var customers_module = __webpack_require__(3230);
var customers_module_default = /*#__PURE__*/__webpack_require__.n(customers_module);
;// CONCATENATED MODULE: ./components/customers/customers.js







const CustomersComponent = ()=>{
    const { customers  } = (0,external_react_redux_.useSelector)(({ customers  })=>customers);
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        dispatch((0,customersSlice/* getCustomersPage */.Fl)());
    }, []);
    console.log(customers.cover_section);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (customers_module_default()).customers,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(pageHeading_section/* PageHeading_section */.$, {
                data: customers.cover_section
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Customers_section, {})
        ]
    });
};

// EXTERNAL MODULE: ./store/store.js
var store = __webpack_require__(5049);
;// CONCATENATED MODULE: ./pages/customers.js





const getServerSideProps = store/* wrapper.getServerSideProps */.Y.getServerSideProps((store)=>async (context)=>{
        await store.dispatch((0,customersSlice/* getCustomersPage */.Fl)());
    });
const CustomersPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "emma website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "My new title"
                    }, "description"),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "My, new, title"
                    }, "keywords")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CustomersComponent, {})
        ]
    });
};
/* harmony default export */ const customers = (CustomersPage);


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [241,895,168,49], () => (__webpack_exec__(1522)));
module.exports = __webpack_exports__;

})();