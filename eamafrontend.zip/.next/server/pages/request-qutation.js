(() => {
var exports = {};
exports.id = 3;
exports.ids = [3];
exports.modules = {

/***/ 4178:
/***/ ((module) => {

// Exports
module.exports = {
	"requestQutation": "requestQutation_requestQutation__NusPK"
};


/***/ }),

/***/ 8556:
/***/ ((module) => {

// Exports
module.exports = {
	"ButtonsS1": "buttons_ButtonsS1__Kn9mZ"
};


/***/ }),

/***/ 6332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonsS1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8556);
/* harmony import */ var _buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function ButtonsS1({ text , iconB , iconA , className , type , loading , disabled =false ,  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "ButtonsS1 " + (_buttons_module_scss__WEBPACK_IMPORTED_MODULE_2___default().ButtonsS1),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
            className: className,
            htmlType: type,
            loading: loading,
            disabled: disabled,
            children: [
                iconB,
                text,
                iconA
            ]
        })
    });
}


/***/ }),

/***/ 6667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ request_qutation),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(241);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./store/slices/quotation/quotationSlice.js
var quotationSlice = __webpack_require__(9856);
// EXTERNAL MODULE: ./components/tools/sections/pageHeading_section.js
var pageHeading_section = __webpack_require__(5895);
// EXTERNAL MODULE: external "antd/lib/input/TextArea"
var TextArea_ = __webpack_require__(5842);
var TextArea_default = /*#__PURE__*/__webpack_require__.n(TextArea_);
// EXTERNAL MODULE: ./components/tools/buttons/buttonsS1.js
var buttonsS1 = __webpack_require__(6332);
;// CONCATENATED MODULE: ./components/request-qutation/form/requestQutation_form.js







const Option = external_antd_.Select;
const RequestQutation_form = ()=>{
    const { quotation  } = (0,external_react_redux_.useSelector)(({ quotation  })=>quotation);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { 0: startDate , 1: setStartDate  } = (0,external_react_.useState)("");
    const { 0: endDate , 1: setEndDate  } = (0,external_react_.useState)("");
    const onFinish = (values)=>{
        dispatch((0,quotationSlice/* quotationFormThunk */.JZ)({
            ...values,
            start_date: startDate,
            end_date: endDate
        })).unwrap().then((res)=>{
            external_antd_.message.success("This is a success message");
        }).catch((res)=>{
            external_antd_.message.error("This is an error message");
        });
    };
    const onFinishFailed = (errorInfo)=>{
        console.log("Failed:", errorInfo);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "form",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Form, {
            name: "basic",
            wrapperCol: {
                span: 16
            },
            onFinish: onFinish,
            onFinishFailed: onFinishFailed,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                    gutter: 20,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "name",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your name!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "Your Name"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "email",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your Email!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "Your email"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "phone",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input Your Phone!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {
                                    placeholder: "Your Phone"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "start_date",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your username!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.DatePicker, {
                                    onChange: (date, dateStrin)=>setStartDate(dateStrin),
                                    format: "YYYY/MM/DD"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "end_date",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your username!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.DatePicker, {
                                    onChange: (date, dateStrin)=>setEndDate(dateStrin),
                                    format: "YYYY/MM/DD"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "location",
                                rules: [
                                    {
                                        required: true,
                                        message: "Please input your username!"
                                    }, 
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Select, {
                                    mode: "tags",
                                    placeholder: "Select Locations",
                                    children: quotation?.locations?.map((location)=>/*#__PURE__*/ jsx_runtime_.jsx(Option, {
                                            value: location.location,
                                            children: location.location
                                        }))
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "other_location",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextArea_default()), {
                                    placeholder: "Other Locations"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 24,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "message",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextArea_default()), {
                                    placeholder: "Message"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(buttonsS1/* default */.Z, {
                    text: "send massage",
                    type: "submit"
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./components/request-qutation/style/requestQutation.module.scss
var requestQutation_module = __webpack_require__(4178);
var requestQutation_module_default = /*#__PURE__*/__webpack_require__.n(requestQutation_module);
;// CONCATENATED MODULE: ./components/request-qutation/requestQutation.js









const RequestQutaitonComponent = ()=>{
    const { quotation  } = (0,external_react_redux_.useSelector)(({ quotation  })=>quotation);
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        dispatch((0,quotationSlice/* getQuotationPage */._c)());
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (requestQutation_module_default()).requestQutation,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(pageHeading_section/* PageHeading_section */.$, {
                data: quotation?.cover_section
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "requestQutationSection container_",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Row, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "imgContainer overlay",
                                style: {
                                    backgroundImage: `url(${quotation?.quotation_section.image})`
                                }
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Col, {
                            xs: 24,
                            lg: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "requestQutationContent",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "subTitle",
                                        children: quotation?.quotation_section.subtitle
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: quotation?.quotation_section.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: quotation?.quotation_section.description
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(RequestQutation_form, {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./store/store.js
var store = __webpack_require__(5049);
;// CONCATENATED MODULE: ./pages/request-qutation.js





const getServerSideProps = store/* wrapper.getServerSideProps */.Y.getServerSideProps((store)=>async (context)=>{
        await store.dispatch((0,quotationSlice/* getQuotationPage */._c)());
    });
const RequestQutationPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "emma website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "My new title"
                    }, "description"),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "My, new, title"
                    }, "keywords")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(RequestQutaitonComponent, {})
        ]
    });
};
/* harmony default export */ const request_qutation = (RequestQutationPage);


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 5842:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input/TextArea");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [241,895,168,49], () => (__webpack_exec__(6667)));
module.exports = __webpack_exports__;

})();