export default function InputSearch({ children }) {

    return <div className="inputS1">
        {children}
    </div>
} 